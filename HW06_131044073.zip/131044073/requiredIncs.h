/* 
 * Includes required class headers for testing
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "Memory.h"
#include "CPU.h"
#include "CPUProgramDyn.h"
#include "Computer.h"

using namespace MyPointerCPUProgram;

#endif /* REQUIREDINCS_H */

