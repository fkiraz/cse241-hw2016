#include "Memory.h"

/*
 * Memory class no parameter constructor
 */
Memory::Memory() : option(0)
{
    for (int i=0;i<50;i++) { // Init memory
        memory[i] = 0;
    }
}

/*
 * Memory class one parameter constructor
 */
Memory::Memory(int opt)
{
    for (int i=0;i<50;i++) { // Init memory
        memory[i] = 0;
    }
    setOption(opt);
}

/*
 * Gets memory value
 */
int Memory::getMem(int position) const
{
    if (position < 50 && position > -1) {
        return memory[position];
    }
    else {
        return 0;
    }
}

/*
 * Sets option value
 */
void Memory::setOption(int option)
{
    if (option == 0 || option == 1 || option == 2) {
        this->option = option;
    }
}

/*
 * Sets memory value
 */
void Memory::setMem(int position, uint8_t value)
{
    if (position < 50 && position > -1) {
        memory[position] = value;
    }
}

/*
 * Prints all memory content to output
 */
void Memory::printAll() const
{
    cout << "Memory Values:" << endl;
    for (int i=0;i<50;i++) {
        cout << "[" << i << "]->" << unsigned(memory[i]) << ", ";
    }
    cout << endl;
}