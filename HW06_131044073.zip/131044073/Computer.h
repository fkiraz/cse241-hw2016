/*
 * Computer Class Header
 * Holds CPU, Memory, CPUProgram objects and uses them
 */

#ifndef COMPUTER_H
#define COMPUTER_H

#include "CPU.h"
#include "CPUProgramDyn.h"
#include "Memory.h"

using namespace MyPointerCPUProgram;

class Computer{
public:
    Computer() : option(0) {}
    Computer(CPU cpu, const CPUProgramDyn prog, Memory mem, int opt);
    Computer(int opt) : option(opt) {}
    inline void setCPU(CPU cpu) { this->cpu = cpu; }
    inline void setMemory(Memory mem) { this->mem = mem; }
    inline void setCPUProgram(CPUProgramDyn prog) { this->prog = prog; }
    inline CPU& getCPU() { return cpu; }
    inline Memory& getMemory() { return mem; }
    inline CPUProgramDyn& getCPUProgram() { return prog; }
    inline int getOption() const { return option; };
    void setOption(int option);
    void execute();

private:
    CPU cpu;
    Memory mem;
    CPUProgramDyn prog;
    int option;
};

#endif /* COMPUTER_H */

