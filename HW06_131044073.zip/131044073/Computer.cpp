#include "Computer.h"

using namespace MyPointerCPUProgram;

/*
 * Computer class four parameter constructor
 */
Computer::Computer(CPU cpu, const CPUProgramDyn prog, Memory mem, int opt)
{
    setCPU(cpu);
    setMemory(mem);
    setCPUProgram(prog);
    this->option = opt;
}

/*
 * Executes instructions from CPUProgram class object
 * on CPU class object with a Memory class object
 */
void Computer::execute()
{
    if (prog.size() == 0) {
        cout << "Nothing to execute. Exiting" << endl;
        return; 
    }
    string instruction;
    cpu.setPC(0);
    while(!cpu.halted()) {
        instruction = prog.getLine(cpu.getPC());
        if (!cpu.execute(instruction, mem)) {
            return;
        }
    }
}