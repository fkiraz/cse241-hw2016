#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include "CPUProgramDyn.h"

using std::ios;

namespace MyPointerCPUProgram {
    /*
     * CPUProgramDyn Class no parameter constructor
     */
    CPUProgramDyn::CPUProgramDyn() : lineCount(0), option(0) {
        fileData = new string[50];
        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
    }
    
    /*
     * CPUProgramDyn Class string parameter constructor
     */
    CPUProgramDyn::CPUProgramDyn(const string fileName) : lineCount(0), option(0) {
        fileData = new string[50];
        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
        ReadFile(fileName);
    }
    
    /*
     * CPUProgramDyn Class integer parameter constructor
     */
    CPUProgramDyn::CPUProgramDyn(const int opt) : lineCount(0) {
        fileData = new string[50];
        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
        if (opt == 0 || opt == 1) {
            option = opt;
        } else {
            option = 0;
        }
    }

    /*
     * CPUProgramDyn Class copy constructor
     */
    CPUProgramDyn::CPUProgramDyn(const CPUProgramDyn &prog) {
        fileData = nullptr;
        *this = prog;
    }

    /*
     * Reads the given file and keeps its data in fileData vector
     */
    bool CPUProgramDyn::ReadFile(const string fileName) {
        if (fileName.empty()) {
            cout << "File was not specified!" << endl;
            return false;
        }
        if (lineCount != 0) { // Delete if already allocated
            delete [] fileData;
            lineCount = 0;
        }
        ifstream file(fileName.c_str());
        string line;
        int lineNumber = 0,i = 0;
        if (!file.good()) {
            cout << "File open error!" << endl;
            return false;
        }
        while(getline(file, line)) { // Get file line count
            lineNumber++;
        }

        lineCount = lineNumber;

        fileData = new string[lineCount]; // Allocate enough data array for file

        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            file.close();
            exit(1);
        }
        file.clear();
        file.seekg(0, ios::beg); // Seek beginning of the file

        while(getline(file, line)) { // Get all file data and push to array
            fileData[i] = line;
            i++;
        }

        file.close();
        return true;
    }

    /*
     * Returns requested line from vector (if it's not out of range)
     */
    string CPUProgramDyn::getLine(const int lineNumber) const {
        if (lineNumber >= lineCount || lineNumber < 0) {
            return "err";
        }
        return fileData[lineNumber];
    }
    
    /*
     * Overloaded assignment operator
     */
    CPUProgramDyn& CPUProgramDyn::operator=(const CPUProgramDyn& obj) {
        if (&obj == this) // Check self-assignment
            return *this;
        
        fileData = new string[obj.lineCount];
        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
        lineCount = 0;
        for (int i=0;i<obj.lineCount;i++) {
            this->addFileData(obj.getLine(i));
        }
        lineCount = obj.lineCount;
        option = obj.option;
        
        return *this;
    }

    /*
     * Overloaded pre-decrement operator
     */
    const CPUProgramDyn& CPUProgramDyn::operator--() {
        if (this->lineCount > 0) {
            this->popFileData();
            this->lineCount--;
        }
        return *this;
    }

    /*
     * Overloaded post-decrement operator
     */
    CPUProgramDyn CPUProgramDyn::operator--(int) {
        CPUProgramDyn obj(*this);
        if (this->lineCount > 0) {
            operator--(); // pre-decrement
        }
        return obj;
    }

    /*
     * Overloaded function call operator
     */
    CPUProgramDyn CPUProgramDyn::operator()(const int begin, const int end) {
        CPUProgramDyn obj;
        if (begin >= 0 && end < this->lineCount && begin < end) { // Check indexes
            for (int i=begin;i<=end;i++) {
                obj.addFileData(this->fileData[i]);
            }
        }
        return obj;
    }

    /*
     * Overloaded index operator
     */
    string CPUProgramDyn::operator[](const int index) {
        if (index >= lineCount || index < 0) { // Return empty string if index is out of range
            return "";
        }
        return this->fileData[index];
    }

    /*
     * Overloaded one string parameter addition operator
     */
    CPUProgramDyn CPUProgramDyn::operator+(const string instruction) {
        CPUProgramDyn obj(*this);
        obj.addFileData(instruction);

        return obj;
    }

    /*
     * Overloaded addition assignment operator
     */
    const CPUProgramDyn& CPUProgramDyn::operator+=(const string instruction) {
        if (instruction.empty()) {
            cout << "Warning : Empty string isn't added" << endl;
        } else {
            addFileData(instruction);
        }
        return *this;
    }

    /*
     * Add given line to data array
     */
    void CPUProgramDyn::addFileData(const string line) {
        reAllocate(lineCount + 1);
        fileData[lineCount-1] = line;
    }

    /*
     * Pop out last line from data array
     */
    void CPUProgramDyn::popFileData() {
        if (lineCount < 1) { 
            return;
        }
        reAllocate(lineCount - 1);
    }

    /*
     * Reallocate file data array
     */
    void CPUProgramDyn::reAllocate(const int newLineCount) {
        string *temp = new string[lineCount];
        if (temp == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
        for (int i=0;i<lineCount;i++) {
            temp[i] = fileData[i];
        }

        delete [] fileData;
        lineCount = newLineCount;
        fileData = new string[lineCount];
        if (fileData == nullptr) {
            cout << "Not enough memory!" << endl;
            exit(1);
        }
        for (int i=0;i<lineCount-1;i++) {
            fileData[i] = temp[i];
        }

        delete [] temp;
    }

    /*
     * Overloaded ostream operator
     */
    ostream& operator<<(ostream& outputStream, const CPUProgramDyn& obj) {
        if (obj.lineCount == 0) {
            outputStream << "Warning: Empty object";
            outputStream << endl;
            return outputStream;
        }
        for (int i=0;i<obj.lineCount;i++) {
            outputStream << obj.getLine(i);
            outputStream << endl;
        }
        return outputStream;
    }

    /*
     * Overloaded two object parameter addition operator
     */
    CPUProgramDyn operator+(const CPUProgramDyn& first, const CPUProgramDyn& other) {
        CPUProgramDyn obj(first);
        for (int i=0;i<other.lineCount;i++) {
            obj.addFileData(other.fileData[i]);
        }
        return obj;
    }
}