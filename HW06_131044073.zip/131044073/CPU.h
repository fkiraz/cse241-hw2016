/*
 * CPU Class Header
 * Holds registers, executes given instruction
 */

#ifndef CPU_H
#define CPU_H

#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include "Memory.h"

using std::cout;
using std::endl;
using std::string;
using std::vector;

class CPU {
public:
    CPU();
    CPU(int option);
    void print() const;
    bool execute(string instruction, Memory &mem);
    
    inline bool halted() const { return isHalted; }
    inline int getPC() const { return PC; }
    inline void setPC(int PC) { this->PC = PC; }
    inline int getRegister(int reg) const { return registers[reg]; }
    inline void setRegister(int reg, int value) { registers[reg] = value; }
    inline int getOption() const { return option; };
    void setOption(int option);
    
private:
    int option;
    int PC;
    vector<int> registers;
    bool isHalted;
    string currInstruction;
    
    string get_first_param() const;
    string get_second_param() const;
    int m_stoi(string str) const;
    int pow(int exp, int base) const;
    bool check_syntax();
    void i_mov(string param, string paramSec, Memory &mem);
    void i_add(string param, string paramSec, Memory &mem);
    void i_sub(string param, string paramSec, Memory &mem);
    void i_jmp(string param, string paramSec);
    void i_jpn(string param, string paramSec);
    void i_hlt(Memory &mem);
    void i_prn(string param, Memory &mem) const;
};

#endif /* CPU_H */

