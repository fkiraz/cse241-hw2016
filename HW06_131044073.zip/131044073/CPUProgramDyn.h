/*
 * CPUProgram Class Header
 * Reads given file and keeps its data to execute
 */

#ifndef CPUPROGRAM_H
#define CPUPROGRAM_H

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;
using std::ifstream;
using std::ostream;

namespace MyPointerCPUProgram {
    class CPUProgramDyn {
    public:
        CPUProgramDyn();
        CPUProgramDyn(const string fileName);
        CPUProgramDyn(const int opt);
        CPUProgramDyn(const CPUProgramDyn &prog);
        ~CPUProgramDyn() { delete [] fileData; }
        bool ReadFile(const string fileName);
        string getLine(const int lineNumber) const;
        int size() const { return lineCount; }
        int getOption() const { return option; };
        void setOption(const int option);

        bool operator<(const CPUProgramDyn& other) {
            return (this->lineCount < other.lineCount); 
        }
        bool operator>(const CPUProgramDyn& other) { 
            return (this->lineCount > other.lineCount); 
        }
        bool operator<=(const CPUProgramDyn& other) {
            return (this->lineCount <= other.lineCount); 
        }
        bool operator>=(const CPUProgramDyn& other) {
            return (this->lineCount >= other.lineCount); 
        }
        bool operator==(const CPUProgramDyn& other) {
            return (this->lineCount == other.lineCount); 
        }
        bool operator!=(const CPUProgramDyn& other) {
            return (this->lineCount != other.lineCount); 
        }
        CPUProgramDyn& operator=(const CPUProgramDyn& obj);
        const CPUProgramDyn& operator--();
        CPUProgramDyn operator--(int);
        CPUProgramDyn operator()(const int begin, const int end);
        string operator[](const int index);
        CPUProgramDyn operator+(const string instruction);
        const CPUProgramDyn& operator+=(const string instruction);
        friend CPUProgramDyn operator+(const CPUProgramDyn& first, const CPUProgramDyn& other);
        friend ostream& operator <<(ostream& outputStream, const CPUProgramDyn& obj);
    private:
        string *fileData;
        int lineCount;
        int option;

        void addFileData(const string line);
        void popFileData();
        void reAllocate(int newLineCount);
    };
}
#endif /* CPUPROGRAM_H */