/*
 * CPUProgram Class Header
 * Reads given file and keeps its data to execute
 */

#ifndef CPUPROGRAM_H
#define CPUPROGRAM_H

#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::ifstream;

class CPUProgram {
public:
    CPUProgram() : lineCount(0), option(0) {};
    CPUProgram(string fileName);
    CPUProgram(int option) : lineCount(0), option(option) {};
    bool ReadFile(string fileName);
    string getLine(int lineNumber) const;
    inline int size() const { return lineCount; }
    inline int getOption() { return option; };
    void setOption(int option);
    
private:
    vector<string> fileData;
    int lineCount;
    int option;
};

#endif /* CPUPROGRAM_H */