/* 
 * File:   main.cpp
 * Author: Fatih_Kiraz_131044073
 *
 * Created on November 5, 2016, 12:35 PM
 */

#include "requiredIncs.h"

using std::cout;
using std::endl;

/*
 * Main for HW04
 */
int main(int argc, char** argv)
{
    if (argc != 3) {
        cout << "Usage : " << argv[0] << " <filename> <option>" << endl;
        return -1;
    }
    if (argv[2][0] != '0' && argv[2][0] != '1' && argv[2][0] != '2') {
        cout << argv[2][0] << " is not a valid option input! Type 0, 1 or 2" << endl;
        return -1;
    }
    
    const char* filename = argv[1]; 
    int option = atoi(argv[2]);
    Memory myMemory(option);
    CPU myCPU(option);
    CPUProgram myCPUProgram(option); 
    
    myCPUProgram.ReadFile(filename); 
    
    Computer myComputer(myCPU, myCPUProgram, myMemory, option); 
    myComputer.execute();
    
    return 0;
}

