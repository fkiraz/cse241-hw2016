/*
 * CPUProgram Class Header
 * Reads given file and keeps its data to execute
 */


#ifndef CPUPROGRAM_H
#define CPUPROGRAM_H

#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

class CPUProgram {
public:
    CPUProgram() : lineCount(0) {};
    CPUProgram(string fileName);
    bool readFile(string fileName);
    string getLine(int lineNumber) const;
    inline int size() const {
        return lineCount;
    }
    
private:
    vector<string> fileData;
    int lineCount;
};

#endif /* CPUPROGRAM_H */