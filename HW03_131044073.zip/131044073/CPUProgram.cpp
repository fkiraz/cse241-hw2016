#include "CPUProgram.h"

/*
 * CPUProgram Class one parameter constructor
 */
CPUProgram::CPUProgram(string fileName){
    lineCount = 0;
    readFile(fileName);
}

/*
 * Reads the given file and keeps its data in fileData vector
 */
bool CPUProgram::readFile(string fileName){
    ifstream file(fileName.c_str());
    string line;
    int lineNumber = 0;
    if (!file.good()) {
        cout << "File open error!" << endl;
        return false;
    }
    
    while(getline(file, line)) { // Get all file data
        fileData.push_back(line);
        lineNumber++;
    }
    lineCount = lineNumber;
    file.close();
    
    return true;
}

/*
 * Returns requested line from vector (if it's not out of range)
 */
string CPUProgram::getLine(int lineNumber) const{
    if (lineNumber > lineCount) {
        return NULL;
    }
    return fileData.at(lineNumber-1);
}