#include "CPU.h"

/*
 * CPU Class one parameter constructor
 */
CPU::CPU(char option)
{
    for (int i=0;i<5;i++) { // Init registers
        registers.push_back(0);
    }
    isHalted = false;
    setPC(1);
    this->option = option;
}

/*
 * Prints the all register content and PC to output
 */
void CPU::print() const
{
    cout << "R1=" << getRegister(0) << " R2=" << getRegister(1) << " R3=" << getRegister(2) << 
            " R4=" << getRegister(3) << " R5=" << getRegister(4) << " - " << "PC=" << getPC() << endl;
}

/*
 * Executes given instruction string
 */
bool CPU::execute(const string instruction)
{
    string param, paramSec, command;
    currInstruction = instruction;
    
    if (currInstruction.empty()) {
        return false;
    }
    if (!check_syntax()) {
        cout << "SYNTAX ERROR AT LINE " << getPC() << ". EXITING" << endl;
        return false;
    }
    param = get_first_param();
    paramSec = get_second_param();
    if (param.compare("ERR") == 0 || paramSec.compare("ERR") == 0) {
        cout << "INVALID PARAMETER AT LINE " << getPC() << ". EXITING" << endl;
        return false;
    }
    command = currInstruction.substr(0, 3);

    if (command.compare("MOV") == 0)
    {
        i_mov(param, paramSec);
        if (option == '1') {
            cout << "MOV " << param << ", " << paramSec << " – ";
            print();
        }
    }
    else if (command.compare("HLT") == 0)
    {
        i_hlt();
        if (option == '1') {
            cout << "HLT – ";
            print();
        }
        return 1;
    }
    else if (command.compare("JMP") == 0)
    {
        i_jmp(param, paramSec);
        if (option == '1') {
            if (param.find("R") != string::npos) {
                cout << "JMP " << param << ", " << paramSec << " – ";
            }
            else {
                cout << "JMP " << param << " – ";
            }
            print();
        }
    }
    else if (command.compare("PRN") == 0)
    {
        i_prn(param);
        if (option == '1') {
            cout << "PRN " << param << " – ";
            print();
        }
    }
    else if (command.compare("SUB") == 0)
    {
        i_sub(param, paramSec);
        if (option == '1') {
            cout << "SUB " << param << ", " << paramSec << " – ";
            print();
        }
    }
    else if (command.compare("ADD") == 0)
    {
        i_add(param, paramSec);
        if (option == '1') {
            cout << "ADD " << param << ", " << paramSec << " – ";
            print();
        }
    }
    else
    {
        cout << "INSTRUCTION ERROR AT LINE " << getPC() << ". EXITING" << endl;
        return false;
    }
    
    PC++;
    return true;
}

/*
 * Gets first parameter from line of instruction
 */
string CPU::get_first_param() const
{
    string returnStr;
    int i = 3;
    returnStr.push_back(currInstruction[i]);
    i++;
    if (returnStr[0] == 82) { // Check if parameter contains R
        if (currInstruction[i] < '0' || currInstruction[i] > '5') { // Check if register is valid
            cout << currInstruction[i] << endl;
            return "ERR";
        }
        returnStr.push_back(currInstruction[i++]);
        if (47 < currInstruction[i] && currInstruction[i] < 58) {
            returnStr.push_back(currInstruction[i]);
        }
    }
    else {
        while (47 < currInstruction[i] && currInstruction[i] < 58 
                || currInstruction[i] == '-') { // Until parameter ends
            if (i == currInstruction.length()) { // Check if reached end of line
                break;
            }
            returnStr.push_back(currInstruction[i]);
            i++;
        }
    }
    return returnStr;
}

/*
 * Gets second parameter from line of instruction
 */
string CPU::get_second_param() const
{
    string returnStr;
    int i, firstOf1, firstOf2;
    firstOf1 = currInstruction.find_first_of(',', 0);
    firstOf2 = currInstruction.find_first_of(';', 0);
    if (firstOf2 != -1 && firstOf1 > firstOf2 || firstOf1 == -1) {
        return "";
    }
    i = firstOf1 + 1;
    returnStr.push_back(currInstruction[i]);
    i++;
    if (returnStr[0] == 'R') { // Check if parameter contains R
        if (currInstruction[i] < '0' || currInstruction[i] > '5') { // Check if register is valid
            return "ERR";
        }
        returnStr.push_back(currInstruction[i++]);
        if (47 < currInstruction[i] && currInstruction[i] < 58) {
            returnStr.push_back(currInstruction[i]);
        }
    }
    else {
        while (47 < currInstruction[i] && currInstruction[i] < 58 
                || currInstruction[i] == '-') { // Until parameter ends
            if (i == currInstruction.length()) { // Check if reached end of line
                break;
            }
            returnStr.push_back(currInstruction[i]);
            i++;
        }
    }
    return returnStr;
}

/*
 * Manuel string to integer function
 * Converts given string to integer
 */
int CPU::m_stoi(string str) const
{
    int length = str.length();
    int result = 0;
    bool minus = false;
    
    for (int i=0;i<length;i++) {
        if (str[i] == '-') {
            minus = true;
        }
        if (str[i] > '/' && str[i] < ':') {
            result += (str[i] - '0') * pow(length - i - 1, 10);
        }
    }
    
    if (minus) {
        result *= -1;
    }
    
    return result;
}

/*
 * Math power function
 */
int CPU::pow(int exp, int base) const
{
    int result = 1;

    while (exp != 0) {
        result *= base;
        --exp;
    }
    
    return result;
}

/*
 * Checks line of instruction syntax
 */
bool CPU::check_syntax()
{
    string temp;
    int count = 0, find;
    temp = "";
    
    for (int i=0;i<currInstruction.length();i++) {
        if (currInstruction.at(i) == ';') {
            break;
        }
        else if (currInstruction.at(i) > 96 && currInstruction.at(i) < 123) { // to upper case
            temp.append(1, (char)(currInstruction.at(i) - 32));
            currInstruction.replace(i, 1, temp);
            temp.clear();
        }
    }
    
    if (currInstruction.find("MOV", 0) == -1 && currInstruction.find("HLT", 0) == -1 && // check for commands
            currInstruction.find("JMP", 0) == -1 && currInstruction.find("PRN", 0) == -1 && 
            currInstruction.find("SUB", 0) == -1 && currInstruction.find("ADD", 0) == -1) {
        return false;
    }
    
    find = currInstruction.find_first_of(' ', 0);
    while (find != -1) { // Remove white spaces
        if (currInstruction.at(count) == ';') {
            break;
        }
        currInstruction.replace(find, 1, temp);
        find = currInstruction.find_first_of(' ', 0);
        count++;
    }
    count = 0;
    
    find = currInstruction.find_first_of('\t', 0);
    while (find != -1) { // Remove tabs
        if (currInstruction.at(count) == ';') {
            break;
        }
        currInstruction.replace(find, 1, temp);
        find = currInstruction.find_first_of('\t', 0);
        count++;
    }
    count = 0;
    if (currInstruction.at(0) == 'M' || currInstruction.at(0) == 'A' || currInstruction.at(0) == 'S') { // check for comma
        for (int i=0;i<currInstruction.length();i++) {
            if (currInstruction.at(i) == ';') {
                break;
            }
            else if (currInstruction.at(i) == ',') {
                count++;
            }
        }

        if (count != 1) { // mov, add, sub should contain only one comma
            return false;
        }
    }
    else if (currInstruction.at(0) == 'P') { // check for prn
        for (int i=3;i<currInstruction.length();i++) {
            if (currInstruction.at(i) == ';') {
                break;
            }
            else if (currInstruction.at(i) < 47 || currInstruction.at(i) > 58) { // should contain only numbers and R
                if (currInstruction.at(i) != 'R') {
                    return false;
                }
            }
        }
    }
    else if (currInstruction.at(0) == 'H') { // check for hlt
        for (int i=3;i<currInstruction.length();i++) {
            if (currInstruction.at(i) == ';') {
                break;
            }
            else {
                return false;
            }
        }
    }
    return true;
}

/*
 * Move instruction
 */
void CPU::i_mov(string param, string paramSec)
{
    if (paramSec.find_first_of('R', 0) == -1) {
        setRegister(param[1] - '1', m_stoi(paramSec));
    }
    else {
        setRegister(paramSec[1] - '1', getRegister(param[1] - '1'));
    }
}

/*
 * Add instruction
 */
void CPU::i_add(string param, string paramSec)
{
    if (paramSec.find_first_of('R', 0) == -1) {
        registers[param[1] - '1'] += m_stoi(paramSec);
    }
    else {
        registers[param[1] - '1'] += registers[paramSec[1] - '1'];
    }
}

/*
 * Sub instruction
 */
void CPU::i_sub(string param, string paramSec)
{
    if (paramSec.find_first_of('R', 0) == -1) {
        registers[param[1] - '1'] -= m_stoi(paramSec);
    }
    else {
        registers[param[1] - '1'] -= registers[paramSec[1] - '1'];
    }
}

/*
 * Jump instruction
 */
void CPU::i_jmp(string param, string paramSec)
{
    if (param.find("R") == string::npos) { // One parameter
        setPC(m_stoi(param) - 1);
    }
    else { // Two parameters
        if (getRegister(param[1] - '1') == 0) {
            setPC(m_stoi(paramSec) - 1);
        }
    }
}

/*
 * Halt instruction
 */
void CPU::i_hlt()
{
    isHalted = true;
    cout << "----------------" << endl << "HALTING" << 
            endl << "----------------" << endl;
    print();
}

/*
 * Print instruction
 */
void CPU::i_prn(string param) const
{
    if (param.find_first_of('R', 0) == -1) {
        cout << param << endl;
    }
    else {
        cout << getRegister(param[1] - '1') << endl;
    }
}