/* 
 * File:   main.cpp
 * Author: Fatih_Kiraz_131044073
 *
 * Created on October 20, 2016, 3:56 PM
 */

#include "CPU.h"
#include "CPUProgram.h"

/*
 * Main code of HW03
 */
int main(int argc, char** argv)
{
    if (argc != 3) {
        cout << "Usage : " << argv[0] << " <filename> <option>" << endl;
        return -1;
    }
    if (argv[2][0] != '0' && argv[2][0] != '1') {
        cout << argv[2][0] << " is not a valid option input! Type 0 or 1" << endl;
        return -1;
    }

    CPUProgram myProg(argv[1]);
    if (myProg.size() == 0) {
        cout << "Nothing to execute. Exiting" << endl;
        return -1; 
    }
    string instruction;
    CPU myCPU(argv[2][0]);
    
    while(!myCPU.halted()) {
        instruction = myProg.getLine(myCPU.getPC());
        if (!myCPU.execute(instruction)) {
            return -1;
        }
    }
    
    return 0;
}