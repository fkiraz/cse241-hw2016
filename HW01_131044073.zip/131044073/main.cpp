/* 
 * File:   main.cpp
 * Author: Fatih_Kiraz_131044073
 *
 * Created on September 27, 2016, 10:11 AM
 */

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int read_file(char* fileName, int option);
string get_first_param(string line);
string get_second_param(string line);
int m_stoi(string str);
int pow(int exp, int base);
bool check_syntax(string *line);
void print_registers(int registers[5]);
void i_mov(string param, string paramSec, int (&registers)[5]);
void i_add(string param, string paramSec, int (&registers)[5]);
void i_sub(string param, string paramSec, int (&registers)[5]);
void i_jmp(string param, string paramSec, int (&registers)[5], int *lineNumber);
void i_hlt(int registers[5]);
void i_prn(string param, int registers[5]);

/*
 * Main code of HW01
 */
int main(int argc, char** argv)
{
    if (argc != 3) {
        cout << "Usage : " << argv[0] << " <filename> <option>" << endl;
        return -1;
    }
    if (argv[2][0] != '0' && argv[2][0] != '1') {
        cout << argv[2][0] << " is not a valid option input! Type 0 or 1" << endl;
        return -1;
    }
    read_file(argv[1], argv[2][0]);
    
    return 0;
}

/*
 * Reads given filename, executes instructions in it
 * Checks for any errors at all lines
 */
int read_file(char* fileName, int option)
{
    int registers[5], lineNumber=0;
    ifstream file(fileName);
    string line, fileData[256], param, paramSec, command;
    if (!file.good()) {
        cout << "File open error!" << endl;
        return -1;
    }
    
    for (int i=0;i<5;i++) { // Init registers
        registers[i] = 0;
    }
    
    while(getline(file, line)) { // Get all file data
        fileData[lineNumber] = line;
        lineNumber++;
    }
    lineNumber = 0;
    
    for (;;) { // Loop for instructions
        line = fileData[lineNumber];
        if (line.empty()) {
            break;
        }
        if (!check_syntax(&line)) {
            cout << "SYNTAX ERROR AT LINE " << ++lineNumber << ". EXITING" << endl;
            break;
        }
        param = get_first_param(line);
        paramSec = get_second_param(line);
        if (param.compare("ERR") == 0 || paramSec.compare("ERR") == 0) {
            cout << "INVALID PARAMETER AT LINE " << ++lineNumber << ". EXITING" << endl;
            break;
        }
        command = line.substr(0, 3);
        
        if (command.compare("MOV") == 0)
        {
            i_mov(param, paramSec, registers);
            if (option == '1') {
                cout << "MOV " << param << ", " << paramSec << " – ";
                print_registers(registers);
            }
        }
        else if (command.compare("HLT") == 0)
        {
            i_hlt(registers);
            if (option == '1') {
                cout << "HLT – ";
                print_registers(registers);
            }
            return 1;
        }
        else if (command.compare("JMP") == 0)
        {
            i_jmp(param, paramSec, registers, &lineNumber);
            if (option == '1') {
                if (param.find("R") != string::npos) {
                    cout << "JMP " << param << ", " << paramSec << " – ";
                }
                else {
                    cout << "JMP " << param << " – ";
                }
                print_registers(registers);
            }
        }
        else if (command.compare("PRN") == 0)
        {
            i_prn(param, registers);
            if (option == '1') {
                cout << "PRN " << param << " – ";
                print_registers(registers);
            }
        }
        else if (command.compare("SUB") == 0)
        {
            i_sub(param, paramSec, registers);
            if (option == '1') {
                cout << "SUB " << param << ", " << paramSec << " – ";
                print_registers(registers);
            }
        }
        else if (command.compare("ADD") == 0)
        {
            i_add(param, paramSec, registers);
            if (option == '1') {
                cout << "ADD " << param << ", " << paramSec << " – ";
                print_registers(registers);
            }
        }
        else
        {
            cout << "INSTRUCTION ERROR AT LINE " << ++lineNumber << ". EXITING" << endl;
            break;
        }
        lineNumber++;
    }
    file.close();
}

/*
 * Gets first parameter from line of instruction
 */
string get_first_param(string line)
{
    string returnStr;
    int i = 3;
    returnStr.push_back(line[i]);
    i++;
    if (returnStr[0] == 82) { // Check if parameter contains register
        if (line[i] < 49 || line[i] > 54) { // Check if register is valid
            return "ERR";
        }
        returnStr.push_back(line[i]);
    }
    else {
        while (47 < line[i] && line[i] < 58) { // Until parameter ends
            if (i == line.length()) { // Check if reached end of line
                break;
            }
            returnStr.push_back(line[i]);
            i++;
        }
    }
    return returnStr;
}

/*
 * Gets second parameter from line of instruction
 */
string get_second_param(string line)
{
    string returnStr;
    int i, firstOf1, firstOf2;
    firstOf1 = line.find_first_of(',', 0);
    firstOf2 = line.find_first_of(';', 0);
    if (firstOf2 != -1 && firstOf1 > firstOf2 || firstOf1 == -1) {
        return "";
    }
    i = firstOf1 + 1;
    returnStr.push_back(line[i]);
    i++;
    if (returnStr[0] == 82) { // Check if parameter contains register
        if (line[i] < 49 || line[i] > 54) { // Check if register is valid
            return "ERR";
        }
        returnStr.push_back(line[i]);
    }
    else {
        while (47 < line[i] && line[i] < 58) { // Until parameter ends
            if (i == line.length()) { // Check if reached end of line
                break;
            }
            returnStr.push_back(line[i]);
            i++;
        }
    }
    return returnStr;
}

/*
 * Manuel string to integer function
 * Converts given string to integer
 */
int m_stoi(string str) 
{
    int length = str.length();
    int result = 0;
    
    for (int i=0;i<length;i++) {
        if (47 > str[i] - '0' && str[i] - '0' < 58) {
            result += (str[i] - '0') * pow(length - i - 1, 10);
        }
    }
    
    return result;
}

/*
 * Math power function
 */
int pow(int exp, int base)
{
    int result = 1;

    while (exp != 0) {
        result *= base;
        --exp;
    }
    
    return result;
}

/*
 * Checks line of instruction syntax
 */
bool check_syntax(string *line)
{
    string temp;
    int count = 0, find;
    temp = "";
    
    find = line->find_first_of(' ', 0);
    while (find != -1) { // Remove white spaces
        if (line->at(count) == ';') {
            break;
        }
        line->replace(find, 1, temp);
        find = line->find_first_of(' ', 0);
        count++;
    }
    count = 0;
    
    find = line->find_first_of('\t', 0);
    while (find != -1) { // Remove tabs
        if (line->at(count) == ';') {
            break;
        }
        line->replace(find, 1, temp);
        find = line->find_first_of('\t', 0);
        count++;
    }
    count = 0;
    
    for (int i=0;i<line->length();i++) {
        if (line->at(i) == ';') {
            break;
        }
        else if (line->at(i) > 96 && line->at(i) < 123) { // to upper case
            temp.append(1, (char)(line->at(i) - 32));
            line->replace(i, 1, temp);
            temp.clear();
        }
    }
    if (line->at(0) == 'M' || line->at(0) == 'A' || line->at(0) == 'S') { // check for comma
        for (int i=0;i<line->length();i++) {
            if (line->at(i) == ';') {
                break;
            }
            else if (line->at(i) == ',') {
                count++;
            }
        }

        if (count != 1) { // mov, add, sub should contain only one comma
            return false;
        }
    }
    else if (line->at(0) == 'P') { // check for prn
        for (int i=3;i<line->length();i++) {
            if (line->at(i) == ';') {
                break;
            }
            else if (line->at(i) < 47 || line->at(i) > 58) { // should contain only numbers and R
                if (line->at(i) != 'R') {
                    return false;
                }
            }
        }
    }
    return true;
}

/*
 * Prints all register contents to output
 */
void print_registers(int registers[5])
{
    cout << "R1=" << registers[0] << " R2=" << registers[1] << " R3=" << registers[2] << 
            " R4=" << registers[3] << " R5=" << registers[4] << endl;
}

/*
 * Move instruction
 */
void i_mov(string param, string paramSec, int (&registers)[5])
{
    if (paramSec.find_first_of('R', 0) == -1) {
        registers[param[1] - '1'] = m_stoi(paramSec);
    }
    else {
        registers[paramSec[1] - '1'] = registers[param[1] - '1'];
    }
}

/*
 * Add instruction
 */
void i_add(string param, string paramSec, int (&registers)[5])
{
    if (paramSec.find_first_of('R', 0) == -1) {
        registers[param[1] - '1'] += m_stoi(paramSec);
    }
    else {
        registers[param[1] - '1'] += registers[paramSec[1] - '1'];
    }
}

/*
 * Sub instruction
 */
void i_sub(string param, string paramSec, int (&registers)[5])
{
    if (paramSec.find_first_of('R', 0) == -1) {
        registers[param[1] - '1'] -= m_stoi(paramSec);
    }
    else {
        registers[param[1] - '1'] -= registers[paramSec[1] - '1'];
    }
}

/*
 * Jump instruction
 */
void i_jmp(string param, string paramSec, int (&registers)[5], int *lineNumber)
{
    if (param.find("R") == string::npos) { // One parameter
        *lineNumber = m_stoi(param) - 2;
    }
    else { // Two parameters
        if (registers[param[1] - '1'] == 0) {
            *lineNumber = m_stoi(paramSec) - 2;
        }
    }
}

/*
 * Halt instruction
 */
void i_hlt(int registers[5])
{
    cout << "----------------" << endl << "HALTING" << 
            endl << "----------------" << endl;
    print_registers(registers);
}

/*
 * Print instruction
 */
void i_prn(string param, int registers[5])
{
    if (param.find_first_of('R', 0) == -1) {
        cout << param << endl;
    }
    else {
        cout << (registers[param[1] - '1']) << endl;
    }
}