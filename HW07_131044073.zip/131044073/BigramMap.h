/* 
 * File:   BigramMap.h
 * Author: Fatih_Kiraz_131044073
 *
 * Created on December 30, 2016, 12:32 AM
 */

#ifndef BIGRAMMAP_H
#define BIGRAMMAP_H

#include <iostream>
#include <string>
#include <map>
#include "Bigram.h"

using std::pair;
using std::string;
using std::map;
using std::make_pair;
using std::endl;

template<class T>
class BigramMap : public Bigram<T> {
public:
    BigramMap(int type) {
        calculatedSoFar = 0;
        dataType = type;
    }
    virtual void readFile(string filename) override;
    virtual int numGrams() const override {
        return calculatedSoFar;
    }
    virtual int numOfGrams(T i1, T i2) override;
    virtual pair<T, T> maxGrams() const override;
    virtual void print(ostream &os) const override {
        for (auto &x : data) {
            os << x.first.first << " " << x.first.second 
                    << " => " << x.second << endl;
        }
    }
    
private:
    int calculatedSoFar;
    int dataType;
    map<pair<T, T>, int> data;
    
    void calculateBigrams(string str);
    int findPair(const T s1, const T s2);
    bool checkString(const string str) const;
};

#endif /* BIGRAMMAP_H */

