/* 
 * File:   Bigram.h
 * Author: Fatih_Kiraz_131044073
 *
 * Created on December 30, 2016, 12:35 AM
 */

#ifndef BIGRAM_H
#define BIGRAM_H

#include <iostream>
#include <string>

using std::pair;
using std::string;
using std::ostream;

template<class T>
class Bigram {
public:
    virtual void readFile(string filename) = 0;
    virtual int numGrams() const = 0;
    virtual int numOfGrams(T i1, T i2) = 0;
    virtual void print(ostream &os) const = 0;
    virtual pair<T, T> maxGrams() const = 0;
private:
    friend ostream& operator<<(ostream &os, Bigram const &b) {
        b.print(os);
        return os;
    }
};

#endif /* BIGRAM_H */

