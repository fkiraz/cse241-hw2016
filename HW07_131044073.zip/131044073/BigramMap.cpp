#include "BigramMap.h"
#include "MyException.h"
#include <fstream>
#include <sstream>
#include <vector>

using std::pair;
using std::string;
using std::ifstream;
using std::cout;
using std::endl;
using std::vector;
using std::istringstream;
using std::getline;
using std::iterator;

template<class T>
void BigramMap<T>::readFile(string filename) {
    calculatedSoFar = 0;
    ifstream file(filename.c_str());
    string line;
    if (!file.good()) {
        throw MyException("File I/O Error");
    }
    if (getline(file, line)) {
        calculateBigrams(line);
    }
    else {
        file.close();
        throw MyException("Empty File");
    }
    file.close();
}

template<class T>
int BigramMap<T>::numOfGrams(T i1, T i2) {
    int index = findPair(i1, i2);
    int i = 0;
    if (index == -1)
        return 0;
    
    else {
        for (auto &x : data) {
            if (i == index)
                return x.second;
            
            i++;
        }
    }
    return -1;
}

template<class T>
pair<T, T> BigramMap<T>::maxGrams() const {
    if (calculatedSoFar == 0)
        MyException("Empty Map");
        
    int maximumSoFar = 0;
    auto result = data.begin();

    for (auto it=data.begin();it!=data.end();it++) {
        if (it->second > maximumSoFar){
            maximumSoFar = it->second;
            result = it;
        }
    }
    return result->first;
}

template<class T>
void BigramMap<T>::calculateBigrams(string str) {
    istringstream ss(str);
    T s1, s2;
    
    ss >> s1;
    while(ss >> s2) {
        pair<T,T> pair1(s1,s2);
        if (findPair(pair1.first, pair1.second) == -1) {
            data[pair1] = 1;
            calculatedSoFar++;
        }
        else {
            data[pair1] = 2;
        }
        s1 = s2;
    }
}

template<class T>
int BigramMap<T>::findPair(const T s1, const T s2) {
    int index = 0;
    for (auto &x : data) {
        if (x.first.first == s1 && x.first.second == s2) {
            return index;
        }
        index++;
    }
    return -1;
}

template<class T>
bool BigramMap<T>::checkString(const string str) const {
    for (int i=0;i<str.size();i++) {
        if (str[i] < 127 && str[i] > 32)
            return true;
    }
    return false;
}