/* 
 * File:   BigramDyn.h
 * Author: Fatih_Kiraz_131044073
 *
 * Created on December 30, 2016, 12:33 AM
 */

#ifndef BIGRAMDYN_H
#define BIGRAMDYN_H

#include <iostream>
#include <string>
#include <vector>
#include "Bigram.h"

using std::cout;
using std::endl;
using std::vector;

template<class T>
class BigramDyn : public Bigram<T> {
public:
    BigramDyn(int type) {
        data = new pair<pair<T, T>, int>[100];
        allocated = 100;
        calculatedSoFar = 0;
        dataType = type;
    }
    BigramDyn(BigramDyn &b) {}
    virtual ~BigramDyn() {
        delete [] data;
    }
    virtual void readFile(string filename) override;
    virtual int numGrams() const override {
        return calculatedSoFar;
    }
    virtual int numOfGrams(T i1, T i2) override;
    virtual pair<T, T> maxGrams() const override;
    virtual void print(ostream &os) const override {
        for (int i=0;i<calculatedSoFar;i++) {
            os << data[i].first.first << " " << data[i].first.second 
                    << " => " << data[i].second << endl;
        }
    }
    
private:
    int calculatedSoFar;
    int allocated;
    int dataType;
    pair<pair<T, T>, int> *data;
    
    void calculateBigrams(string str);
    int findPair(const T s1, const T s2);
    bool checkString(const string str) const;
};

#endif /* BIGRAMDYN_H */

