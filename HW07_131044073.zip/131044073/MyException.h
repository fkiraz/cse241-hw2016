/* 
 * File:   MyException.h
 * Author: Fatih_Kiraz_131044073
 *
 * Created on December 31, 2016, 10:59 AM
 */

#ifndef MYEXCEPTION_H
#define MYEXCEPTION_H

#include <exception>

using std::exception;

class MyException : public exception {
public:
    MyException() noexcept {}
    MyException(const MyException&) noexcept {}
    MyException(string ex) noexcept {
        this->ex = ex;
    }
    MyException& operator= (const MyException&) noexcept {}
    virtual ~MyException() {}
    virtual const char* what() const noexcept {
        return ex.c_str();
    }
private:
    string ex;
};

#endif /* MYEXCEPTION_H */

