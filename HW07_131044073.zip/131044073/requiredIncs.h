/* 
 * File:   requiredIncs.h
 * Author: Fatih_Kiraz_131044073
 *
 * Created on January 1, 2017, 9:29 AM
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include <iostream>
#include <cstdlib>
#include "Bigram.h"
#include "BigramDyn.h"
#include "BigramMap.h"
#include "BigramDyn.cpp"
#include "BigramMap.cpp"

using namespace std;

#endif /* REQUIREDINCS_H */

