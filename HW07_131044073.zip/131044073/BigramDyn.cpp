#include "BigramDyn.h"
#include "MyException.h"
#include <fstream>
#include <sstream>
#include <vector>

using std::pair;
using std::string;
using std::ifstream;
using std::cout;
using std::endl;
using std::vector;
using std::istringstream;
using std::getline;

template<class T>
void BigramDyn<T>::readFile(string filename) {
    calculatedSoFar = 0;
    ifstream file(filename.c_str());
    string line;
    if (!file.good()) {
        throw MyException("File I/O Error");
    }
    if (getline(file, line)) {
        if (!checkString(line))
            throw MyException("Empty File");
            
        calculateBigrams(line);
    }
    else {
        file.close();
        throw MyException("File I/O Error");
    }
    file.close();
}

template<class T>
int BigramDyn<T>::numOfGrams(T i1, T i2) {
    int index = findPair(i1, i2);
    if (index == -1)
        return 0;
    
    else 
        return data[index].second;
}

template<class T>
pair<T, T> BigramDyn<T>::maxGrams() const {
    int maximumSoFar = 0;
    int returnIndex = 0;
    for (int i=0;i<calculatedSoFar;i++) {
        if (data[i].second > maximumSoFar) {
            maximumSoFar = data[i].second;
            returnIndex = i;
        }
    }
    return data[returnIndex].first;
}

template<class T>
void BigramDyn<T>::calculateBigrams(string str) {
    istringstream ss(str);
    int searchIndex = 0;
    T s1, s2;
    
    ss >> s1;
    while(ss >> s2) {
        pair<T,T> pair1(s1,s2);
        searchIndex = findPair(pair1.first, pair1.second);
        if (searchIndex == -1) {
            if (calculatedSoFar >= allocated) {
                pair<pair<T, T>, int> *temp = new pair<pair<T, T>, int>[allocated];
                for (int i=0;i<allocated;i++) {
                    temp[i] = data[i];
                }
                allocated+=100;
                delete [] data;
                data = new pair<pair<T, T>, int>[allocated];

                for (int i=0;i<allocated-100;i++) {
                    data[i] = temp[i];
                }

                delete [] temp;
            }
            pair<pair<T,T>, int> pair2(pair1, 1);
            data[calculatedSoFar] = pair2;
            calculatedSoFar++;
        }
        else {
            data[searchIndex].second++;
        }
        s1 = s2;
    }
}

template<class T>
int BigramDyn<T>::findPair(const T s1, const T s2) {
    for (int i=0;i<calculatedSoFar;i++) {
        if (data[i].first.first == s1 && data[i].first.second == s2) {
            return i;
        }
    }
    return -1;
}

template<class T>
bool BigramDyn<T>::checkString(const string str) const {
    for (int i=0;i<str.size();i++) {
        if (str[i] < 127 && str[i] > 32)
            return true;
    }
    return false;
}