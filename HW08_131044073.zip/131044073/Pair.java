/**
 *
 * @author Fatih_Kiraz_131044073
 * @param <K>
 * @param <V>
 */
public class Pair<K, V> {
    private final K elem1;
    private final V elem2;

    public Pair(K elem1, V elem2) {
        this.elem1 = elem1;
        this.elem2 = elem2;
    }

    public K getKey() {
        return elem1;
    }

    public V getValue() {
        return elem2;
    }
}
