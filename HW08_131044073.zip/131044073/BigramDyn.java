import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author Fatih_Kiraz_131044073
 */

class BigramDyn<T> implements Bigram<T> 
{
    private final T data[];
    private final int dataCount[];
    private final int dataType; // 1: int 2: string 3: double
    private int calculatedSoFar = 0;
    private int x = 0;
    private int dataSize = 0;
    
    @SuppressWarnings("unchecked")
    BigramDyn(int type) {
        dataType = type;
        data = (T[]) new Object[1024];
        dataCount = new int[1024];
        for (int j=0;j<1024;j++) {
            dataCount[j] = 1;
        }
    }
    
    /**
     * Reads given file and inserts all pairs to data
     * Error checks included
     * 
     * @param filename
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws TypeCheckException 
     */
    @Override
    @SuppressWarnings("unchecked")
    public void readFile(String filename) throws IOException, UnsupportedEncodingException, TypeCheckException {
        String status = null;
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF8"));
            status = reader.readLine();
            reader.close();
        } catch (UnsupportedEncodingException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
            
        if (status == null) {
            throw new IOException("Empty file");
        }
        if (status.trim().length() < 2) { // Check empty file
            throw new IOException("Empty file");
        }
        
        Object split[] = status.split(" ");
        Object temp = null;
        int index;

        for (Object o : split) {
            if (calculatedSoFar > 512) {
                break;
            }
            if (temp != null) {
                if (!checkPairValidity(temp, o)) { // Check pair
                    throw new TypeCheckException("Invalid types " + temp + " " + o);
                }
                index = findPair(temp, o);
                if (index == -1) {
                    data[x] = (T) temp;
                    data[x + 1] = (T) o;
                    x += 2;
                    dataSize++;
                }
                else {
                    dataCount[index / 2]++;
                }
                calculatedSoFar++;
            }
            temp = o;
        }
    }

    /**
     * Returns total number of calculated bigrams
     * 
     * @return calculated bigrams so far
     */
    @Override
    public int numGrams() {
        return calculatedSoFar;
    } 

    /**
     * Finds given pair and returns its repeat count
     * 
     * @param t1
     * @param t2
     * @return bigram count
     */
    @Override
    public int numOfGrams(T t1, T t2) {
        int result = findPair(t1, t2);
        
        if (result != -1) {
            return dataCount[result / 2];
        }
        
        return result + 1;
    }
    
    /**
     * Returns string form of data
     * 
     * @return string data
     */
    @Override
    public String toString() {
        String result = "";
        int i = 0;
        
        for (int j=0;j<dataSize;j++) {
            result += data[i];
            result += " ";
            result += data[i + 1];
            result += " => ";
            result += dataCount[j];
            result += "\n";
            i += 2;
        }
        
        return result;
    }
    
    /**
     * Searches given pair in array data
     * 
     * @param t1
     * @param t2
     * @return index of pair
     */
    private int findPair(Object t1, Object t2) {
        int i = 0, k = 1;
        
        for (int j=0;j<dataSize;j++) {
            if (data[i].equals(t1) && data[k].equals(t2)) {
                return i;
            }
            i += 2;
            k += 2;
        }
        return -1;
    }
    
    /**
     * Checks pair type if correct
     * 
     * @param t1
     * @param t2
     * @return validity of types
     */
    private boolean checkPairValidity(Object t1, Object t2) {
        if (dataType == 1) {
            try {
                Integer.parseInt(t1.toString());
                Integer.parseInt(t2.toString());
            } catch(NumberFormatException ex) {
                return false;
            }
        }
        else if (dataType == 3) {
            try {
                Double.parseDouble(t1.toString());
                Double.parseDouble(t2.toString());
            } catch(NumberFormatException ex) {
                return false;
            }
        }
        
        return true;
    }
}
