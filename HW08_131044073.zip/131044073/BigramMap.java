import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Fatih_Kiraz_131044073
 */

class BigramMap<T> implements Bigram<T> 
{
    private final HashMap<Pair<T, T>, Integer> data;
    private int calculatedSoFar = 0;
    private final int dataType; // 1: int 2: string 3: double
    
    BigramMap(int type) {
        data = new HashMap<>();
        dataType = type;
    }
    
    /**
     * Reads given file and inserts all pairs to data
     * Error checks included
     * 
     * @param filename
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws TypeCheckException 
     */
    @Override
    @SuppressWarnings("unchecked")
    public void readFile(String filename) throws IOException, UnsupportedEncodingException, TypeCheckException {
        String status = null;
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF8"));
            status = reader.readLine();
            reader.close();
        } catch (UnsupportedEncodingException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
        if (status == null) {
            throw new IOException("Empty file");
        }
        if (status.trim().length() < 2) { // Check empty file
            throw new IOException("Empty file");
        }
        
        Object split[] = status.split(" "); // Split by whitespace
        Object temp = null;
        boolean found;

        for (Object o : split) { // Create pairs
            found = false;
            if (temp != null) { // Ignore first data
                if (!checkPairValidity(temp, o)) { // Check pair
                    throw new TypeCheckException("Invalid types " + temp + " " + o);
                }
                for (Map.Entry<Pair<T, T>, Integer> entry : data.entrySet()) { // Search for pair
                    if (entry.getKey().getKey().toString().equals(temp) && entry.getKey().getValue().toString().equals(o)) {
                        entry.setValue(entry.getValue() + 1); // Increase value if pair found
                        found = true;
                        break;
                    }
                }
                if (!found) { // Add pair to map
                    if (dataType == 1) {
                        data.put(new Pair(Integer.parseInt(temp.toString()), Integer.parseInt(o.toString())), 1);
                    }
                    else if (dataType == 3) {
                        data.put(new Pair(Double.parseDouble(temp.toString()), Double.parseDouble(o.toString())), 1);
                    }
                    else {
                        data.put(new Pair(temp.toString(), o.toString()), 1);
                    }
                }
                calculatedSoFar++;
            }
            temp = o;
        }
    }

    /**
     * Returns total number of calculated bigrams
     * 
     * @return calculated bigrams so far
     */
    @Override
    public int numGrams() {
        return calculatedSoFar;
    }

    /**
     * Finds given pair and returns its repeat count
     * 
     * @param t1
     * @param t2
     * @return bigram count
     */
    @Override
    public int numOfGrams(T t1, T t2) {
        for (Map.Entry<Pair<T, T>, Integer> entry : data.entrySet()) {
            if (entry.getKey().getKey().equals(t1) && entry.getKey().getValue().equals(t2)) {
                return entry.getValue();
            }
        }
        
        return 0;
    }
    
    /**
     * Returns string form of data
     * 
     * @return string data
     */
    @Override
    public String toString() {
        String result = "";
        for (Map.Entry<Pair<T, T>, Integer> entry : data.entrySet()) {
            result += entry.getKey().getKey();
            result += " ";
            result += entry.getKey().getValue();
            result += " => ";
            result += entry.getValue();
            result += "\n";
        }
        
        return result;
    }
    
    /**
     * Checks pair type if correct
     * 
     * @param t1
     * @param t2
     * @return validity of types
     */
    private boolean checkPairValidity(Object t1, Object t2) {
        if (dataType == 1) {
            try {
                Integer.parseInt(t1.toString());
                Integer.parseInt(t2.toString());
            } catch(NumberFormatException ex) {
                return false;
            }
        }
        else if (dataType == 3) {
            try {
                Double.parseDouble(t1.toString());
                Double.parseDouble(t2.toString());
            } catch(NumberFormatException ex) {
                return false;
            }
        }
        
        return true;
    }
}
