import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author Fatih_Kiraz_131044073
 * @param <T>
 */
public interface Bigram<T> {
    public void readFile(String filename) throws IOException, UnsupportedEncodingException, TypeCheckException;
    public int numGrams();
    public int numOfGrams(T t1, T t2);
    @Override
    public String toString();
}
