/**
 *
 * @author Fatih_Kiraz_131044073
 */
class TypeCheckException extends Exception {
    public TypeCheckException(String string) {
        super(string);
    }
}
