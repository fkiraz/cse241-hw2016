/*
 * Memory Class Header
 * Holds memory
 */

#ifndef MEMORY_H
#define MEMORY_H

#include <cstdint>
#include <iostream>

using std::cout;
using std::endl;

class Memory{
public:
    Memory();
    Memory(int option);
    int getMem(int position) const;
    inline int getOption() const { return option; };
    void setOption(int option);
    void setMem(int position, uint8_t value);
    void printAll() const;
    
private:
    uint8_t memory[50];
    int option;
};

#endif /* MEMORY_H */

