#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "CPUProgram.h"

/*
 * CPUProgram Class one parameter constructor
 */
CPUProgram::CPUProgram(string fileName){
    lineCount = 0;
    ReadFile(fileName);
}

/*
 * Reads the given file and keeps its data in fileData vector
 */
bool CPUProgram::ReadFile(string fileName){
    if (fileName.empty()) {
        cout << "File was not specified!" << endl;
        return false;
    }
    ifstream file(fileName.c_str());
    string line;
    int lineNumber = 0;
    if (!file.good()) {
        cout << "File open error!" << endl;
        return false;
    }
    
    while(getline(file, line)) { // Get all file data
        fileData.push_back(line);
        lineNumber++;
    }
    lineCount = lineNumber;
    file.close();
    
    return true;
}

/*
 * Returns requested line from vector (if it's not out of range)
 */
string CPUProgram::getLine(int lineNumber) const {
    if (lineNumber >= lineCount || lineNumber < 0) {
        return "err";
    }
    return fileData.at(lineNumber);
}

/*
 * Overloaded pre-decrement operator
 */
const CPUProgram& CPUProgram::operator--() {
    if (this->lineCount > 0) {
        this->fileData.pop_back();
        this->lineCount--;
    }
    return *this;
}

/*
 * Overloaded post-decrement operator
 */
CPUProgram CPUProgram::operator--(int) {
    CPUProgram temp(*this);
    if (this->lineCount > 0) {
        operator--(); // pre-decrement
    }
    return temp;
}

/*
 * Overloaded function call operator
 */
CPUProgram CPUProgram::operator()(const int begin, const int end) {
    CPUProgram obj;
    if (begin >= 0 && end < this->lineCount && begin < end) { // Check indexes
        for (int i=begin;i<=end;i++) {
            obj.fileData.push_back(this->fileData.at(i));
            obj.lineCount++;
        }
    }
    return obj;
}

/*
 * Overloaded index operator
 */
string CPUProgram::operator[](const int index) {
    if (index >= lineCount || index < 0) { // Return empty string if index is out of range
        return "";
    }
    return this->fileData.at(index);
}

/*
 * Overloaded one string parameter addition operator
 */
CPUProgram CPUProgram::operator+(const string instruction) {
    CPUProgram obj(*this);
    obj.fileData.push_back(instruction);
    obj.lineCount++;
    return obj;
}

/*
 * Overloaded addition assignment operator
 */
const CPUProgram& CPUProgram::operator+=(const string instruction) {
    fileData.push_back(instruction);
    lineCount++;
    return *this;
}

/*
 * Overloaded ostream operator
 */
ostream& operator <<(ostream& outputStream, const CPUProgram& obj) {
    if (obj.lineCount == 0) {
        outputStream << "Warning: Empty object";
        outputStream << endl;
        return outputStream;
    }
    for (int i=0;i<obj.lineCount;i++) {
        outputStream << obj.getLine(i);
        outputStream << endl;
    }
    return outputStream;
}

/*
 * Overloaded two object parameter addition operator
 */
CPUProgram operator+(const CPUProgram& first, const CPUProgram& other) {
    CPUProgram obj(first);
    for (int i=0;i<other.lineCount;i++) {
        obj.fileData.push_back(other.fileData.at(i));
        obj.lineCount++;
    }
    return obj;
}