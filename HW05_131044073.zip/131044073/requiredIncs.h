/* 
 * Includes required class headers for testing
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "Memory.h"
#include "CPU.h"
#include "CPUProgram.h"
#include "Computer.h"

#endif /* REQUIREDINCS_H */

