/*
 * CPUProgram Class Header
 * Reads given file and keeps its data to execute
 */

#ifndef CPUPROGRAM_H
#define CPUPROGRAM_H

#include <iostream>
#include <vector>
#include <string>

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::ifstream;
using std::ostream;

class CPUProgram {
public:
    CPUProgram() : lineCount(0), option(0) {};
    CPUProgram(string fileName);
    CPUProgram(int option) : lineCount(0), option(option) {};
    bool ReadFile(string fileName);
    string getLine(int lineNumber) const;
    int size() const { return lineCount; }
    int getOption() const { return option; };
    void setOption(int option);
    
    bool operator<(const CPUProgram& other) {
        return (this->lineCount < other.lineCount); 
    }
    bool operator>(const CPUProgram& other) { 
        return (this->lineCount > other.lineCount); 
    }
    bool operator<=(const CPUProgram& other) {
        return (this->lineCount <= other.lineCount); 
    }
    bool operator>=(const CPUProgram& other) {
        return (this->lineCount >= other.lineCount); 
    }
    bool operator==(const CPUProgram& other) {
        return (this->lineCount == other.lineCount); 
    }
    bool operator!=(const CPUProgram& other) {
        return (this->lineCount != other.lineCount); 
    }
    const CPUProgram& operator--();
    CPUProgram operator--(int);
    CPUProgram operator()(const int begin, const int end);
    string operator[](const int index);
    CPUProgram operator+(const string instruction);
    const CPUProgram& operator+=(const string instruction);
    friend CPUProgram operator+(const CPUProgram& first, const CPUProgram& other);
    friend ostream& operator <<(ostream& outputStream, const CPUProgram& obj);
private:
    vector<string> fileData;
    int lineCount;
    int option;
};

#endif /* CPUPROGRAM_H */